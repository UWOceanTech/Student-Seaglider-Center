% Dive 4 as of 20 Apr 2024 03:57:38
% SG194 Shilshole Shakedown
volmax = 53011.5;
vbdbias = 65.289; % vbdbias w rms = 0.93 cm/s
volmax_biased = 52946.2;
abs_compress = 1.30997e-06;
hd_a = 0.00281838;
hd_b = 0.011885;
hd_c = 5.7e-06;
hd_s = -0.25;
therm_expan = 7.05e-05;
temp_ref = 15;
