% Dive 2 as of 20 Apr 2024 03:57:38
% SG194 Shilshole Shakedown
volmax = 53011.5;
vbdbias = 21.9151; % vbdbias w rms = 0.82 cm/s
volmax_biased = 52989.6;
abs_compress = 8.13637e-06;
hd_a = 0.00281838;
hd_b = 0.011885;
hd_c = 5.7e-06;
hd_s = -0.25;
therm_expan = 7.05e-05;
temp_ref = 15;
