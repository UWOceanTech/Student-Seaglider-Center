% Dive 1 as of 20 Apr 2024 03:57:37
% SG194 Shilshole Shakedown
volmax = 53011.5;
vbdbias = 55.0246; % vbdbias w rms = 0.84 cm/s
volmax_biased = 52956.5;
abs_compress = 2.41879e-06;
hd_a = 0.00281838;
hd_b = 0.011885;
hd_c = 5.7e-06;
hd_s = -0.25;
therm_expan = 7.05e-05;
temp_ref = 15;
